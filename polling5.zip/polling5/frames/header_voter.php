<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<script src="jscript/validation.js" type="text/javascript"></script>
</head>

<body bgcolor="#EBE9E9">
<marquee>Welcome To Online Voting System </marquee>
<center><font size='6' >
<a href="voter.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="lan_view.php">Vote Results</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="profile.php">Profile</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="logout.php">Logout</a>
&nbsp;&nbsp;|&nbsp;&nbsp;<a href="change_pass.php">Change Password</a>
</font></center> 
