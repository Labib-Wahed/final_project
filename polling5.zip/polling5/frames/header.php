
<html>
<head>
<style> 
body {
  background-image: url("./images/vote.jpg");
  background-color: #cccccc;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting System</title>
<script src="jscript/validation.js" type="text/javascript"></script>
</head>

<marquee>Welcome To Online Voting System</marquee>
<center><font size='8' >
<a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="register.php">Register</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="login.php">Login</a></font></center> 
<br>
<br>